/*
    MSSV: 19127582
    Name: Nguyen Trung Tin
*/

#include <iostream>
// #include <stdio.h>
using namespace std;

int main() {
    printf("               *\n");
    printf("         *     *    *\n");
    printf("    *    *     *    *    *\n");
    printf("*   *    *     *    *    *    *\n");    


    return 0;
}

