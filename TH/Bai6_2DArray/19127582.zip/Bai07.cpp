#include <iostream>
#include <climits>

using namespace std;

int main() {
    double a[100][100];
    int n;
    cout << "Nhap n: ", cin >> n;

    for(int i = 0; i < n; i++) {
        for(int j = 0; j < n; j++) {
            cout << "Nhap a[" << i << "][" << j << "] = ", cin >> a[i][j];
        }
    }

    int 
        max = INT_MIN,
        result = -1;

    cout << "Dong co tong lon nhat la dong: " << '\n';
    for(int i = 0; i < n; i++) {
        int sum = 0;
        for(int j = 0; j < n; j++) {
            sum += a[i][j];
        }
        if(sum >= max) {
            max = sum;
            // result = i;
        }
    }
    for(int i = 0; i < n; i++) {
        int sum = 0;
        for(int j = 0; j < n; j++) {
            sum += a[i][j];
        }
        if(sum >= max) {
            cout << i << " ";
        }
    }
    cout << endl;
    system("pause");
    return 0;
}